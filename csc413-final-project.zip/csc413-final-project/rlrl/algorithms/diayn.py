import torch
import torch as T
import torch.nn as nn
import torch.nn.functional as F

from pathlib import Path
from rlrl.algorithms.sac import SAC, CriticNetwork, ActorNetwork
from rlrl.networks import LinearNetwork
from torch.utils.tensorboard import SummaryWriter
from torch.distributions import Normal
from torch import Tensor, nn
import numpy as np


import torch.nn.functional as F
from typing import Optional


class DIAYN(SAC):
    """
    "Diversity is All You Need" 
    https://arxiv.org/abs/1802.06070
    """

    def __init__(self,
                 state_vec_size,
                 action_vec_size,
                 training_args,
                 writer: Optional[SummaryWriter] = None
                 ):
        """

        Args:

        q1,q2,qf1,qf2: Q-value functions from Soft Actor Critic
        df: Discriminator function
        Skills: Number of skills
        """
        super().__init__(
            state_vec_size, state_vec_size + training_args.skills,
            action_vec_size, training_args, writer
        )

        self.skills_dim = self.args.skills
        self.skills_prior = nn.Parameter(
            torch.full((self.skills_dim,), 1 / self.skills_dim),
            requires_grad=False
        )

        self.meta_policy = LinearNetwork(state_vec_size, [256, 256, self.args.skills], activation_fn=nn.ReLU)
        self.meta_policy_optimizer = torch.optim.Adam(self.meta_policy.parameters(), lr=self.args.lr)

        self.df = LinearNetwork(state_vec_size, [256, 256, self.args.skills], activation_fn=nn.ReLU)
        self.df_optimizer = torch.optim.Adam(self.df.parameters(), lr=self.args.lr)

    def sample_random_skill(self):
        skill_idx = torch.multinomial(self.skills_prior, 1)
        return F.one_hot(skill_idx, self.skills_dim).squeeze()

    def choose_skill(self, states):
        skills_pri = self.meta_policy(states)
        skill_probs = F.softmax(skills_pri, dim=-1)

        skill_idx = skill_probs.argmax(dim=-1)
        return F.one_hot(skill_idx, self.skills_dim)

    def forward(
            self,
            state: Tensor,
            skill: Tensor = None,
            deterministic: bool = False
        ):
        if skill is None:
            skill = self.choose_skill(state)

        act_obs = self.make_observation(state, skill)
        return super().forward(state, act_obs, deterministic)

    def make_observation(self, state: Tensor, skill: Tensor):
        return torch.cat((state, skill), dim=-1)

    def learn_discriminator(self, experience):
        _, _, _, next_states, _, skills = experience
        _, df_loss = self.get_rewards(next_states, skills)

        self.df_optimizer.zero_grad()
        df_loss.backward()
        self.df_optimizer.step()

        return df_loss.detach().cpu().item()

    def learn(self, experience, loss_func=F.mse_loss):
        states, actions, rewards, next_states, terminals, _ = experience

        # Train Critic networks
        predicted_next_val = self.target_value(next_states)
        target_q = (
                rewards + (1 - terminals) * self.args.decay * predicted_next_val
        ).detach()

        predicted_q1 = self.critic_1(states, actions)
        predicted_q2 = self.critic_2(states, actions)

        q1_loss = loss_func(predicted_q1, target_q)
        q2_loss = loss_func(predicted_q2, target_q)
        critic_avg_loss = 0.5 * q1_loss + 0.5 * q2_loss

        self.critic_1.optimizer.zero_grad()
        self.critic_2.optimizer.zero_grad()
        critic_avg_loss.backward()
        self.critic_1.optimizer.step()
        self.critic_2.optimizer.step()

        # Train Value network
        skills = self.choose_skill(states)
        actor_inp = self.make_observation(states, skills)

        predicted_actions, log_probs, _ = self.actor(actor_inp)
        predicted_new_q_value = T.min(self.critic_1(states, predicted_actions),
                                      self.critic_2(states, predicted_actions))

        target_val = predicted_new_q_value - log_probs
        predicted_val = self.value(states)
        val_loss = loss_func(predicted_val, target_val.detach())

        self.value.optimizer.zero_grad()
        val_loss.backward()
        self.value.optimizer.step()
        self.update_target_value_network_params(tau=self.args.polyak)

        # Train Actor network
        self.meta_policy_optimizer.zero_grad()
        self.actor.optimizer.zero_grad()
        actor_loss = -T.mean(target_val)
        actor_loss.backward()
        self.meta_policy_optimizer.step()
        self.actor.optimizer.step()

        # Return updated Q-value prediction and target
        with torch.no_grad():
            predicted_next_val_updated = self.target_value(next_states)
            updated_target_q = (
                    rewards
                    + (1 - terminals) * self.args.decay * predicted_next_val_updated
            )

        disc_loss = self.learn_discriminator(experience)

        self.training_steps += 1

        if self.writer is not None:
            self.writer.add_scalar(
                "Train/Critic Loss by Steps",
                critic_avg_loss.detach().cpu().item(), self.training_steps
            )
            self.writer.add_scalar(
                "Train/Value Loss by Steps", val_loss.detach().cpu().item(),
                self.training_steps
            )
            self.writer.add_scalar(
                "Train/Actor Loss by Steps", actor_loss.detach().cpu().item(),
                self.training_steps
            )
            self.writer.add_scalar(
                "Train/Discriminator Loss by Steps", disc_loss,
                self.training_steps
            )

        return predicted_next_val_updated, updated_target_q

    def get_rewards(
            self,
            state,
            skill,
            loss_func=F.cross_entropy
        ):
        skill_idxs = torch.argmax(skill, dim=-1)

        disc_out = self.df(state)
        prob_expected = self.skills_prior[..., skill_idxs]

        disc_log_probs = F.log_softmax(disc_out, 1)[..., skill_idxs]
        disc_reward = torch.mean(disc_log_probs - torch.log(prob_expected))

        df_loss = loss_func(disc_out, skill_idxs)

        return disc_reward.detach().cpu().item(), df_loss
