from collections import OrderedDict
from pathlib import Path
from typing import Any, Optional, Tuple
from copy import deepcopy

import torch.nn.functional as F
import torch.optim
from torch import Tensor, nn
import torch as T
from torch.utils.tensorboard import SummaryWriter

from rlrl.networks import LinearNetwork, LinearCatNetwork
from rlrl.networks.gaussian import TanhGaussianNetwork
from rlrl.algorithms.algorithm import Algorithm


class SAC(Algorithm):

    def __init__(
            self,
            state_vec_size,
            actor_vec_size,
            action_vec_size,
            training_args,
            writer: Optional[SummaryWriter] = None
    ):
        super().__init__(training_args.device)

        self.writer = writer
        self.args = training_args

        self.actor = ActorNetwork(actor_vec_size, action_vec_size, lr=self.args.lr)
        self.critic_1 = CriticNetwork(state_vec_size, action_vec_size, lr=self.args.lr)
        self.critic_2 = CriticNetwork(state_vec_size, action_vec_size, lr=self.args.lr)

        # used in training. target_value network is a soft copy of the value network since the
        # critic loss depends on the value network, and the value loss depends on the critic networks
        self.value = ValueNetwork(state_vec_size, lr=self.args.lr)
        self.target_value = deepcopy(self.value)
        self.update_target_value_network_params()

    def forward(self, state: Tensor, act_obs: Tensor = None, deterministic: bool = False) -> Any:
        if act_obs is None:
            act_obs = state

        action, _, _ = self.actor(act_obs, deterministic)
        q = min(self.critic_1(state, action), self.critic_2(state, action))
        
        return action, q

    def learn(self, experience, loss_func=F.mse_loss):
        states, actions, rewards, next_states, terminals = experience

        # Train Critic networks
        predicted_next_val = self.target_value(next_states)
        target_q = (
                rewards + (1 - terminals) * self.args.decay * predicted_next_val
        ).detach()

        predicted_q1 = self.critic_1(states, actions)
        predicted_q2 = self.critic_2(states, actions)

        q1_loss = loss_func(predicted_q1, target_q)
        q2_loss = loss_func(predicted_q2, target_q)
        critic_avg_loss = 0.5 * q1_loss + 0.5 * q2_loss

        self.critic_1.optimizer.zero_grad()
        self.critic_2.optimizer.zero_grad()
        critic_avg_loss.backward()
        self.critic_1.optimizer.step()
        self.critic_2.optimizer.step()

        # Train Value network
        predicted_actions, log_probs, _ = self.actor(states)
        predicted_new_q_value = T.min(self.critic_1(states, predicted_actions),
                                      self.critic_2(states, predicted_actions))

        target_val = predicted_new_q_value - log_probs
        predicted_val = self.value(states)
        val_loss = loss_func(predicted_val, target_val.detach())

        self.value.optimizer.zero_grad()
        val_loss.backward()
        self.value.optimizer.step()
        self.update_target_value_network_params(tau=self.args.polyak)

        # Train Actor network
        self.actor.optimizer.zero_grad()
        actor_loss = -T.mean(target_val)
        actor_loss.backward()
        self.actor.optimizer.step()

        # Return updated Q-value prediction and target
        with torch.no_grad():
            predicted_next_val_updated = self.target_value(next_states)
            updated_target_q = (
                    rewards
                    + (1 - terminals) * self.args.decay * predicted_next_val_updated
            )

        self.training_steps += 1

        if self.writer is not None:
            self.writer.add_scalar(
                "Train/Critic Loss by Steps",
                critic_avg_loss.detach().cpu().item(), self.training_steps
            )
            self.writer.add_scalar(
                "Train/Value Loss by Steps", val_loss.detach().cpu().item(),
                self.training_steps
            )
            self.writer.add_scalar(
                "Train/Actor Loss by Steps", actor_loss.detach().cpu().item(),
                self.training_steps
            )

        return predicted_next_val_updated, updated_target_q

    def update_target_value_network_params(self, tau=1):
        target_value_param_dict = OrderedDict(self.target_value.named_parameters())  # ordered dict to fix type hints
        value_param_dict = OrderedDict(self.value.named_parameters())

        for param_name in value_param_dict:
            target_value_param_dict[param_name] = tau * value_param_dict[param_name].clone() + \
                                                  (1 - tau) * target_value_param_dict[param_name].clone()

        self.target_value.load_state_dict(target_value_param_dict)

    def save(self, path: Path) -> None:
        save_dict = {
            "state": self.state_dict(),
            "training_steps": self.training_steps
        }

        T.save(save_dict, str(path / "model-{}.zip".format(self.training_steps)))

    def load(self, path: Path) -> None:
        print(f'loading {str(path)}')
        load_dict = T.load(str(path), map_location=self.args.device)
        self.load_state_dict(load_dict["state"])
        self.training_steps = load_dict["training_steps"]


class ValueNetwork(nn.Module):
    def __init__(self, state_vec_size, h_dims=(256, 256), lr=1e-4):
        super().__init__()
        self.linearNetwork = LinearNetwork(num_input_units=state_vec_size,
                                           layer_sizes=list(h_dims) + [1],
                                           activation_fn=nn.ReLU)
        self.optimizer = torch.optim.Adam(self.parameters(), lr=lr)  # thanks professor ba :D

    def forward(self, state: Tensor) -> float:
        return self.linearNetwork(state)


class ActorNetwork(nn.Module):
    def __init__(self, state_vec_size, action_vec_size, h_dims=(256, 256), lr=1e-4):
        super().__init__()
        self.gaussianNetwork = TanhGaussianNetwork(num_input_units=state_vec_size,
                                                   layer_sizes=list(h_dims) + [action_vec_size],
                                                   activation_fn=nn.ReLU)
        self.optimizer = torch.optim.Adam(self.parameters(), lr=lr)

    def forward(
            self,
            state: Tensor,
            deterministic: bool = False,
        ) -> Tuple[Tensor, Tensor, Tensor]:
        """
        Calculates the agent action on state.

        Args:
            state: The state to take the action for.
            deterministic: If the sample should be the means of the
            distribution.

        Returns:
            The agent action for the state, log probability and mean of the
            action distribution.
        """
        return self.gaussianNetwork(state, deterministic)


class CriticNetwork(nn.Module):
    def __init__(self, state_vec_size, action_vec_size, h_dims=(256, 256), lr=1e-4):
        super().__init__()
        self.linearNetwork = LinearCatNetwork(input_sizes=(state_vec_size, action_vec_size),
                                              layer_sizes=list(h_dims) + [1],
                                              activation_fn=nn.ReLU)
        self.optimizer = torch.optim.Adam(self.parameters(), lr=lr)

    def forward(self, state: Tensor, action: Tensor) -> float:
        return self.linearNetwork(state, action)
