from abc import ABC, abstractmethod
from typing import Any, Union

import torch
from torch import nn

class Algorithm(nn.Module, ABC):
    """
    A reinforcement learning algorithm.
    """
    def __init__(self, device: Union[str, torch.device] = "cpu"):
        """
        An abstract algorithm that logs training steps.
        """
        super().__init__()

        self.device = device
        self.training_steps = 0

    @abstractmethod
    def learn(self, *args: Any, **kwargs: Any) -> None:
        """
        Do backwards pass of the algorithm
        """
        raise NotImplementedError

    @abstractmethod
    def save(self, path: str) -> None:
        """
        Saves the model state to the path given.

        Args:
            path: The path to save the model state to.
        """
        raise NotImplementedError

    @abstractmethod
    def load(self, path: str) -> None:
        """
        Reads and loads the model state saved at the path.

        Args:
            path: The path to the file containing the model state.
        """
        raise NotImplementedError

