from enum import Enum


class RunTypes(str, Enum):
    TRAIN = "train"
    PLAY = "play"


class AlgoType(str, Enum):
    SAC = "sac"
    DIAYN = "diayn"


if __name__ == "__main__":
    from argparse import ArgumentParser
    from pathlib import Path

    import numpy as np
    import torch
    from torch.utils.tensorboard import SummaryWriter

    from rlrl.agents import Agent, DIAYNAgent
    from rlrl.env import create_env
    from rlrl.algorithms.sac import SAC
    from rlrl.algorithms.diayn import DIAYN
    from rlrl.experience_replay import PER

    parser = ArgumentParser(description="Train SAC on Rocket League")

    parser.add_argument(
        "run_type", type=RunTypes,
        choices=[run_type.value for run_type in RunTypes],
        help="a choice between training and playing"
    )

    parser.add_argument(
        "algo", type=AlgoType,
        choices=[algo.value for algo in AlgoType],
        help="a choice between SAC and DIAYN"
    )

    # Playing
    parser.add_argument(
        "-e", "--episodes", type=int, default=10,
        help="the number of episodes to play for"
    )

    # Training
    parser.add_argument(
        "-t", "--training_steps", type=int, default=100_000_000,
        help="the number of steps to train for"
    )
    parser.add_argument(
        "-s", "--save", default="sac_runs", type=Path,
        help="the path to models and logs to"
    )
    parser.add_argument(
        "-l", "--load", type=Path, help="the path to the saved model to load"
    )
    parser.add_argument(
        "-d", "--device", type=torch.device,
        default=torch.device("cuda" if torch.cuda.is_available() else "cpu"),
        help="the device to train on (cuda or cpu)"
    )

    parser.add_argument(
        "--decay", type=float, default=0.995, help="the discount factor"
    )
    parser.add_argument(
        "--polyak", type=float, default=5e-3,
        help="the averaging constant to update the target networks"
    )
    parser.add_argument(
        "--lr", type=float, default=1e-4, help="the learning rate"
    )

    parser.add_argument(
        "--batch_size", type=int, default=1024,
        help="the size of each training batch"
    )
    parser.add_argument(
        "--initialization_size", type=int, default=10_000,
        help="the number of experience to collect before training starts"
    )
    parser.add_argument(
        "--save_interval", type=int, default=10_000,
        help="the number of training steps in between model saves"
    )

    parser.add_argument(
        "--n_steps", type=int, default=30,
        help="the number of steps to discount",
    )
    # Arguments for DIAYN
    parser.add_argument(
        "--skills", type=int, default=20,
        help="the number of skills",
    )
    parser.add_argument(
        "--skill_pretrain_steps", type=int, default=10_000,
        help="the number of pretrain steps to take for skills",
    )

    # Arguments for PER
    parser.add_argument(
        "--er_capacity", type=int, default=100_000,
        help="the maximum amount of experiences in the replay buffer"
    )
    parser.add_argument(
        "--er_alpha", type=float, default=0.6, help="the alpha value for PER"
    )
    parser.add_argument(
        "--er_beta", type=float, default=0.4, help="the alpha value for PER"
    )
    parser.add_argument(
        "--er_beta_increment", type=float, default=1e-4,
        help="the increment of the beta value after each sample for PER"
    )
    parser.add_argument(
        "--er_epsilon", type=float, default=1e-5,
        help="the epsilon value for PER"
    )
    args = parser.parse_args()

    # Make the save path if needed
    args.save.mkdir(parents=True, exist_ok=True)

    logs_path = args.save / "logs"
    logs_path.mkdir(exist_ok=True)

    # Create tensorboard writer
    writer = SummaryWriter(str(logs_path))

    if args.run_type == RunTypes.PLAY:
        env, _ = create_env(1)
    else:
        env, terminal_conditions = create_env()

    state_size = np.prod(env.observation_space.shape)
    num_actions = np.sum(env.action_space.shape)

    per_input_sizes = [(state_size,), (num_actions,), (1,), (state_size,), (1,)]

    if args.algo == AlgoType.DIAYN:
        algo = DIAYN(state_size, num_actions, args, writer).to(args.device)
        agent = DIAYNAgent(algo, env, args.skill_pretrain_steps, writer)
        per_input_sizes.append((args.skills,))
        print('Using DIAYN')
    else:
        algo = SAC(state_size, state_size, num_actions, args, writer).to(args.device)
        agent = Agent(algo, env, writer)
        print('Using SAC')

    

    if args.load is not None:
        algo.load(args.load)

    if args.run_type == RunTypes.PLAY:
        algo.eval()
        agent.play(args.episodes)
    else:
        algo.train()

        model_path = args.save / "models"
        model_path.mkdir(exist_ok=True)


        replay = PER(
            per_input_sizes, args.er_capacity, args.er_alpha, args.er_beta,
            args.er_beta_increment, args.er_epsilon, args.device
        )

        agent.train(
            args.training_steps, terminal_conditions, replay, args.batch_size,
            args.initialization_size, args.decay, args.n_steps,
            args.save_interval, model_path
        )
