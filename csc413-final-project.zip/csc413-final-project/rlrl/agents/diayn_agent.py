from typing import Optional, Tuple
from time import time

import torch
from torch.utils.tensorboard import SummaryWriter
from gym import Env

from rlrl.algorithms.diayn import DIAYN
from rlrl.agents.agent import Agent
from rlrl.experience_replay import PER
from rlrl.env.terminals import ArtificialTerminalCondition


class DIAYNAgent(Agent):
    """
    Trains an off-policy DIAYN algorithm.
    """
    def __init__(
            self,
            algo: DIAYN,
            env: Env,
            skill_pretrain_steps: int,
            writer: Optional[SummaryWriter] = None
        ):
        """
        Creates the agent for the algorithm on the environment, storing
        experiences in the replay buffer.

        Args:
            algo: The algorithm to train.
            env: The environment to train on.
            writer: The writer to log agent statistics.
        """
        super().__init__(algo, env, writer)
        self.skills_pretrain_steps = skill_pretrain_steps

    def train(
            self,
            steps: int,
            terminal_conditions: Tuple[ArtificialTerminalCondition],
            replay: PER,
            batch_size: int,
            initialization_size: int,
            decay: float,
            n_steps: int,
            save_interval: int,
            save_path: str
        ) -> None:
        """
        Starts training the algorithm.

        Args:
            steps: The number of environment steps to train for.
            terminal_conditions: The terminal conditions for the environment,
                used to detect timeouts.
            replay: The replay buffer to store experiences in.
            batch_size: The batch size to use for training.
            initialization_size: The number of experiences to collect before
                training starts.
            decay: The discount factor for temporal differences.
            n_steps: The number of steps to discount to calculate returns.
            save_interval: The number of steps in between model saves.
            save_path: The path to save models to.
        """
        self.algo.train()

        states = []
        actions = []
        rewards = []
        terminals = []
        q_vals = []
        skills = []

        skill = None

        if self.algo.training_steps < self.skills_pretrain_steps:
            skill = self.algo.sample_random_skill()

        skill_step = 0

        state = self.env.reset()
        state = torch.tensor(
            state, device=self.algo.device, dtype=torch.float32
        )

        episode = 1
        episode_reward = 0
        episode_steps = 0

        start_time = time()

        for i in range(1, steps + 1):
            step_start = time()

            if skill is None:
                used_skill = self.algo.choose_skill(state.unsqueeze(0))
            else:
                used_skill = skill.unsqueeze(0)

            with torch.no_grad():
                action, q_value = self.algo(state.unsqueeze(0), used_skill)

            next_state, reward, terminal, _ = self.env.step(action.cpu().numpy())

            real_terminal = any(
                terminal_condition.is_env_terminal()
                for terminal_condition in terminal_conditions
            )

            next_state = torch.tensor(
                next_state, device=self.algo.device, dtype=torch.float32
            )

            episode_reward += reward

            with torch.no_grad():
                disc_reward, _ = self.algo.get_rewards(
                    next_state.unsqueeze(0), used_skill
                )

                # If in pretraining phase or not
                if skill is None:
                    reward += disc_reward
                else:
                    reward = disc_reward

            states.append(state)
            actions.append(action)
            rewards.append(reward)
            terminals.append(real_terminal)
            q_vals.append(q_value)
            skills.append(used_skill.squeeze(0))

            if terminal:
                states.append(next_state)

                with torch.no_grad():
                    _, next_q_val = self.algo(next_state, skill)

                q_vals.append(next_q_val)

                skill = None
                if self.algo.training_steps < self.skills_pretrain_steps:
                    skill = self.algo.sample_random_skill()

                skill_step = 0

                state = self.env.reset()
                state = torch.tensor(
                    state, device=self.algo.device, dtype=torch.float32
                )

                print("Episode {}: {}".format(episode, episode_reward))
            else:
                state = next_state

            while len(actions) > n_steps or (terminal and len(actions) > 0):
                # Only need n_steps length, but want n_steps + 1 so the
                # experience transition has a next state and next q value for
                # the last state and q value
                self.add_to_replay_buffer(
                    replay, states[:n_steps + 1], actions[:n_steps],
                    rewards[:n_steps], terminals[:n_steps],
                    q_vals[:n_steps + 1], skills[:n_steps], decay
                )

                states = states[1:]
                actions = actions[1:]
                rewards = rewards[1:]
                terminals = terminals[1:]
                q_vals = q_vals[1:]
                skills = skills[1:]

            if (len(replay) >= batch_size
                    and len(replay) >= initialization_size):
                batch, indices = replay.sample(batch_size)

                new_q, new_q_target = self.algo.learn(batch)

                replay.set_priorities(
                    indices, new_q.flatten(), new_q_target.flatten()
                )

                if self.algo.training_steps % save_interval == 0:
                    self.algo.save(save_path)

            episode_steps += 1

            if self.writer is not None and (i % 20 == 0 or terminal):
                step_time = time() - step_start
                step_time = 1e-10 if step_time == 0 else step_time  # was getting a division by 0 error for some reason

                self.writer.add_scalar(
                    "Train/Time per Step", step_time, self.algo.training_steps
                )
                self.writer.add_scalar(
                    "Train/Steps per Second", 1 / step_time,
                    self.algo.training_steps
                )

                if terminal:
                    self.writer.add_scalar(
                        "Train/Episode Reward by Episode", episode_reward,
                        episode
                    )

                    self.writer.add_scalar(
                        "Train/Episode Reward by Wallclock Time",
                        episode_reward, time() - start_time
                    )

                    self.writer.add_scalar(
                        "Train/Episode Length", episode_steps, episode
                    )

            skill_step += 1

            if skill_step % n_steps == 0:
                skill = None
                if self.algo.training_steps < self.skills_pretrain_steps:
                    skill = self.algo.sample_random_skill()

                skill_step = 0

            if terminal:
                episode += 1
                episode_reward = 0
                episode_steps = 0

    def get_buffer_experience(
            self,
            states: Tuple[torch.Tensor, ...],
            actions: Tuple[torch.Tensor, ...],
            rewards: Tuple[float, ...],
            terminals: Tuple[bool, ...],
            q_vals: Tuple[torch.Tensor, ...],
            skills: Tuple[torch.Tensor, ...],
            decay: int,
        ):
        """
        Gets the experience to add to the replay buffer.

        Args:
            states: The states of the experiences.
            actions: The actions of the experiences.
            rewards: The rewards of the experiences.
            terminals: For each experience, true if the experience was terminal.
            q_vals: The Q-values for each action taken.
            skills: The skills that the actions were taken under.
            decay: The discount factor for N-step returns.
        """
        rewards[0] = self.discount_reward(rewards, terminals, decay)

        experience = [
            states[0],
            actions[0],
            torch.tensor(
                rewards[0], device=self.algo.device, dtype=torch.float32
            ),
            states[1],
            torch.tensor(
                terminals[0], device=self.algo.device, dtype=torch.float32
            ),
            skills[0]
        ]

        return experience, q_vals[0], q_vals[1]

    def add_to_replay_buffer(
            self,
            replay: PER,
            states: Tuple[torch.Tensor, ...],
            actions: Tuple[torch.Tensor, ...],
            rewards: Tuple[float, ...],
            terminals: Tuple[bool, ...],
            q_vals: Tuple[torch.Tensor, ...],
            skills: Tuple[torch.Tensor, ...],
            decay: int,
        ) -> None:
        """
        Adds the first transition in the local buffer to the replay buffer.

        Args:
            replay: The replay buffer to store experiences in.
            states: The states of the experiences.
            actions: The actions of the experiences.
            rewards: The rewards of the experiences.
            terminals: For each experience, true if the experience was terminal.
            q_vals: The Q-values for each action taken.
            skills: The skills the actions were taken under.
            decay: The discount factor for N-step returns.
        """
        replay.add(*self.get_buffer_experience(
            states, actions, rewards, terminals, q_vals, skills, decay
        ))
