"""
CSC413 Final Project - Rocket League Reinforcement Learning
"""

__version__ = "0.0.0"

