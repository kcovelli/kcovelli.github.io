from argparse import ArgumentError
from typing import Iterable, Tuple, Type

import torch
from torch import nn
from torch.distributions import Normal

from rlrl.networks.linear import LinearNetwork

class GaussianNetwork(nn.Module):
    """
    A Gaussian network, a series of linear layers that produce a vector of means
    and standard deviations for a Gaussian.
    """
    def __init__(
            self,
            num_input_units: int,
            layer_sizes: list[int],
            activation_fn: Type[nn.Module],
            gaussian: Type[Normal],
            log_std_min: float = -20,
            log_std_max: float = 2,
            bias: bool = True
        ):
        """
        Creates a series of linear layers, each with the activation function
        in between with the exception of the last layer. The parameters of
        the Gaussian is produced.

        Args:
            num_input_units: The number of input units.
            layer_sizes: The number of units in each layer.
            activation_fn: The activation function between each layer.
            gaussian: The Gaussian distribution to use (GMM/Multivariate/etc.)
            log_std_min: The minimum log standard deviation to rescale to.
            log_std_max: The maximum log standard deviation to rescale to.
            bias: If a bias should be added to each layer.
        """
        super().__init__()

        if len(layer_sizes) == 0:
            raise ArgumentError(
                "There must be at least 1 layer for the Gaussian model!"
            )

        self.log_std_min = log_std_min
        self.log_std_max = log_std_max
        self.gaussian = gaussian

        # Multiply by 2 to calculate means and stds at same time
        self.gaussian_size = int(layer_sizes[-1])
        layer_sizes[-1] *= 2

        self.linear = LinearNetwork(
            num_input_units, layer_sizes, activation_fn, bias
        )

    def calculate_gaussians(
            self,
            inp: torch.Tensor
        ) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Calculates the mean and log standard deviation of the Gaussians.

        Args:
            inp: The input tensor to put through the network.

        Returns:
            A mean and log standard deviation of the Gaussians.
        """
        linear = self.linear(inp)
        mean, log_std = torch.split(linear, self.gaussian_size, dim=-1)

        # Bound log std for stability
        log_std = torch.tanh(log_std)
        log_std = (
            (log_std + 1) * (self.log_std_max - self.log_std_min)
            + self.log_std_min
        )

        return mean, log_std

    def forward(
            self,
            inp: torch.Tensor,
            deterministic: bool = False,
        ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Returns a sample of the network on the input with the mean and log
        probability of the sample.

        Args:
            inp: The input tensor to put through the network.
            deterministic: If the sample should be the means of the
            distribution.

        Returns:
            The sample, log probability and mean of the sample.
        """
        mean, log_std = self.calculate_gaussians(inp)

        std = log_std.exp()
        normal = self.gaussian(mean, std)

        if deterministic:
            action = normal.mean
        else:
            action = normal.rsample()

        log_prob = normal.log_prob(action).sum(dim=-1, keepdim=True)

        return action, log_prob, normal.mean

class TanhGaussianNetwork(GaussianNetwork):
    """
    A tanh Gaussian network with ouputs squished to the range (-1, 1).
    """
    def __init__(
            self,
            num_input_units: int,
            layer_sizes: Iterable[int],
            activation_fn: Type[nn.Module],
            log_std_min: float = -20,
            log_std_max: float = 2,
            bias: bool = True,
            epsilon: float = 1e-5
        ):
        """
        Creates a series of linear layers, each with the activation function
        in between with the exception of the last layer. The parameters of
        the independent Gaussians are produced.

        Args:
            num_input_units: The number of input units.
            layer_sizes: The number of units in each layer.
            activation_fn: The activation function between each layer.
            log_std_min: The minimum log standard deviation to rescale to.
            log_std_max: The maximum log standard deviation to rescale to.
            bias: If a bias should be added to each layer.
            epsilon: The fudge factor to apply when calculating log
                probabilities for stability.
        """
        super().__init__(
            num_input_units, layer_sizes, activation_fn, Normal, log_std_min,
            log_std_max, bias
        )

        self.epsilon = epsilon

    def forward(
            self,
            inp: torch.Tensor,
            deterministic: bool = False,
        ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Returns a sample of the network on the input with the mean and log
        probability of the sample.

        Args:
            inp: The input tensor to put through the network.
            deterministic: If the sample should be the means of the
            distribution.

        Returns:
            The sample, log probability and mean of the sample.
        """
        sample, log_prob, mean = super().forward(inp, deterministic)
        sample = torch.tanh(sample)

        log_prob -= torch.log(1 - torch.pow(sample, 2) + self.epsilon).sum(
            dim=-1, keepdim=True
        )

        mean = torch.tanh(mean)

        return sample, log_prob, mean
