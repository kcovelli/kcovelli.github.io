from typing import Iterable, Type

import torch
from torch import nn

class LinearNetwork(nn.Module):
    """
    A series of linear layers.
    """
    def __init__(
            self,
            num_input_units: int,
            layer_sizes: Iterable[int],
            activation_fn: Type[nn.Module],
            bias: bool = True
        ):
        """
        Creates a series of linear layers, each with the activation function
        in between with the exception of the last layer.

        Args:
            num_input_units: The number of input units.
            layer_sizes: The number of units in each layer.
            activation_fn: The activation function between each layer.
            bias: If a bias should be added to each layer.
        """
        super().__init__()

        all_layer_sizes = [num_input_units] + layer_sizes
        first_layers = []

        for i in range(len(all_layer_sizes) - 2):
            first_layers += self._linear_block(
                all_layer_sizes[i], all_layer_sizes[i + 1], activation_fn,
                bias=bias
            )

        self.linear = nn.Sequential(
            *first_layers,
            (
                nn.Linear(all_layer_sizes[-2], all_layer_sizes[-1], bias=bias)
                if len(layer_sizes) > 0 else nn.Identity()
            )
        )

    def _linear_block(
            self,
            num_input_units: int,
            num_output_units: int,
            activation_fn: Type[nn.Module],
            bias: bool
        ) -> list[nn.Module]:
        """
        Creates a linear block consisting of a linear layer and the activation
        function.

        Args:
            num_input_units: The number of input units.
            num_output_units: The number of output units.
            activation_fn: The activation function after the linear layer.
            bias: If the linear layer should have bias.

        Returns:
            A module composed of the linear layer with the activation function.
        """
        return [
            nn.Linear(num_input_units, num_output_units, bias=bias),
            activation_fn()
        ]

    def forward(self, inp: torch.Tensor) -> torch.Tensor:
        """
        Calculates the network output for the input.

        Args:
            inp: The input to the network.

        Returns:
            The result of applying the linear layers to the input.
        """
        return self.linear(inp)

class LinearCatNetwork(LinearNetwork):
    """
    A linear network that takes multiple inputs to be concatenated before they
    are passed into the first layer.
    """
    def __init__(
            self,
            input_sizes: Iterable[int],
            layer_sizes: Iterable[int],
            activation_fn: Type[nn.Module],
            bias: bool = True
        ):
        """
        Creates the linear network that 

        Args:
            input_sizes: The size of each input to the network.
            layer_sizes: The number of units in each layer.
            activation_fn: The activation function between each layer.
            bias: If a bias should be added to each layer.
        """
        super().__init__(sum(input_sizes), layer_sizes, activation_fn, bias)

    def forward(self, *inp: torch.Tensor) -> torch.Tensor:
        """
        Calculates the network output for the inputs.

        Args:
            inp: The input to the network.

        Returns:
            The result of applying the linear layers to the input.
        """
        return self.linear(torch.cat(inp, dim=-1))
