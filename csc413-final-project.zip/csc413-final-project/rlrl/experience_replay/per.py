from typing import Tuple

import torch

class PER:
    """
    Prioritized Experience Replay by Schaul et al.
    https://arxiv.org/abs/1511.05952
    """
    def __init__(
            self,
            input_sizes: Tuple[Tuple[int, ...], ...],
            capacity: int,
            alpha: float,
            beta: float,
            beta_increment: float,
            epsilon: float = 1e-7,
            device = "cpu"
        ):
        """
        Creates a PER buffer with the given parameters.

        Args:
            input_sizes: The sizes for each input of an experience.
            capacity: The capacity of PER.
            alpha: The prioritization constant.
            beta: The importance sampling constant.
            beta_increment: The increment of beta after every sample.
            epsilon: A fudge factor added to the errors to avoid NaNs.
            device: The torch device to store the experiences on.
        """
        self.capacity = capacity
        self.alpha = alpha
        self.beta = beta
        self.beta_increment = beta_increment
        self.epsilon = epsilon

        self.experiences = [
            torch.zeros((capacity, *input_size), device=device)
            for input_size in input_sizes
        ]

        self.priorities = torch.zeros((capacity,), device=device)
        self.count = 0
        self.cursor = 0
        self.priority_sum = 0

    def __len__(self) -> int:
        """
        The amount of experience in the buffer.

        Returns:
            The number of experiences currently in the buffer.
        """
        return self.count

    def get_priority(self, error: torch.Tensor) -> float:
        """
        Calculates the priority in the replay buffer for an error.

        Args:
            error: The error to calculate the priority for.
        
        Returns:
            The priority for the error.
        """
        return (error + self.epsilon) ** self.alpha

    def get_error(
            self,
            q_val: torch.Tensor,
            q_target: torch.Tensor
        ) -> torch.Tensor:
        """
        Calculates the error between a Q-value prediction and its Q-target.

        Args:
            q_val: The Q-value estimation of an experience.
            q_target: The target Q-value for the experience.

        Returns:
            The TD error between the Q-value and its target.
        """
        return torch.abs(q_val - q_target)

    def add(
            self,
            experience: Tuple[torch.Tensor, ...],
            q_val: torch.Tensor,
            q_target: torch.Tensor,
        ) -> None:
        """
        Adds the experience to the buffer.

        Args:
            experience: The experience to add.
            q_val: The Q-value estimate of the experience.
            q_target: The target Q-value of experience.
        """
        error = self.get_error(q_val, q_target)
        priority = self.get_priority(error).item()

        # Remove update priority in sum
        self.priority_sum -= self.priorities[self.cursor].item()
        self.priority_sum += priority
        self.priorities[self.cursor] = priority

        for i in range(len(experience)):
            self.experiences[i][self.cursor] = experience[i]

        self.count = min(self.count + 1, self.capacity)
        self.cursor = (self.cursor + 1) % self.capacity

    def sample(
            self,
            size: int
        ) -> Tuple[Tuple[torch.Tensor, ...], torch.Tensor, torch.Tensor]:
        """
        Samples experiences from the replay buffer.

        Args:
            size: The number of experiences to sample.
        
        Returns:
            A tuple of the sample, IDs of the experiences, and their importance
            sampling weights.
        """
        priorities = self.priorities[:len(self)] / self.priority_sum
        indices = torch.multinomial(priorities, size)

        experiences = [
            experience[indices] for experience in self.experiences
        ]

        self.beta = min(1.0, self.beta + self.beta_increment)

        return experiences, indices

    def set_priorities(
            self,
            ids: torch.Tensor,
            q_vals: torch.Tensor,
            q_targets: torch.Tensor
        ) -> None:
        """
        Sets the priorities of a batch of experience using their Q-values and
        Q-targets.

        Args:
            ids: The ids of the experiences to set.
            q_vals: The Q-values of the experiences.
            q_targets: The target Q-values of the experiences.
        """
        errors = self.get_error(q_vals, q_targets)
        priorities = self.get_priority(errors)

        self.priority_sum -= self.priorities[ids].sum().item()
        self.priority_sum += priorities.sum().item()
        self.priorities[ids] = priorities
