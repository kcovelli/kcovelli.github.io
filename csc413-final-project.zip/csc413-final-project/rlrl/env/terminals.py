from abc import ABC

from rlgym.utils.gamestates import GameState
from rlgym.utils.terminal_conditions.common_conditions import (
    TimeoutCondition, GoalScoredCondition
)

class ArtificialTerminalCondition(ABC):
    """
    An artificial terminal condition, making sure that terminal states are ones
    defined by the environment rather than external factors. Used to enforce
    correct terminal checking as shown in:
    https://arxiv.org/pdf/1712.00378.pdf
    """
    def __init__(self):
        """
        Creates the artifical terminal condition with a property to state
        if the last state tested was a real terminal.
        """
        self._real_terminal = False

    def reset(self, initial_state: GameState) -> None:
        """
        Sets real terminal to false.

        Args:
            initial_state: The initial state of the environment.
        """
        self.real_terminal = False

    @property
    def real_terminal(self) -> bool:
        return self._real_terminal

    @real_terminal.setter
    def real_terminal(self, terminal: bool) -> None:
        self._real_terminal = terminal

    def is_env_terminal(self) -> bool:
        """
        Checks to see if the environment has truly terminated.

        Returns:
            True if the underlying environment has terminated.
        """
        return self.real_terminal

class ArtificialTimeoutCondition(TimeoutCondition, ArtificialTerminalCondition):
    """
    A timeout condition that also checks to see if the environment has
    terminated.
    """
    def reset(self, initial_state: GameState) -> None:
        """
        Resets the step counter.

        Args:
            initial_state: The initial state of the environment.
        """
        TimeoutCondition.reset(self, initial_state)
        ArtificialTerminalCondition.reset(self, initial_state)

class ArtificialGoalScoredCondition(GoalScoredCondition, ArtificialTerminalCondition):
    """
    A condition that checks to see if the environment has terminated through a
    goal being scored.
    """
    def reset(self, initial_state: GameState) -> None:
        """
        Reset if a goal has been scored to false.

        Args:
            initial_state: The initial state of the environment.
        """
        GoalScoredCondition.reset(self, initial_state)
        ArtificialTerminalCondition.reset(self, initial_state)

    def is_terminal(self, current_state: GameState) -> bool:
        """
        Detects if the environment has terminated through a goal being scored.

        Args:
            current_state: The current state of the environment.

        Returns:
            True if a goal has been scored.
        """
        if current_state.blue_score != self.blue_score or current_state.orange_score != self.orange_score:
            self.blue_score = current_state.blue_score
            self.orange_score = current_state.orange_score
            self.real_terminal = True
        else:
            self.real_terminal = False

        return self.real_terminal
