import numpy as np

from rlgym.utils import RewardFunction
from rlgym.utils.common_values import CEILING_Z
from rlgym.utils.gamestates import GameState, PlayerData


class HeightReward(RewardFunction):
    """
    A reward based on how high the car is.
    """
    def reset(self, initial_state: GameState):
        pass

    def get_reward(self, player: PlayerData, state: GameState, previous_action: np.ndarray) -> float:
        """
        Gets the normalized reward based on how close a player is to the
        ceiling.

        Args:
            player: The player to get the reward for.
            state: The current game state.
            previous_action: The previous action taken by the player.

        Returns:
            The reward for how close a player is to the ceiling.
        """
        return player.car_data.position[2] / CEILING_Z
