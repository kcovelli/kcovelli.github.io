import numpy as np
from gym.spaces import Space, Box
from rlgym.utils import common_values
from rlgym.utils.gamestates import GameState
from rlgym.utils.action_parsers import ActionParser


class ContinuousThresholdAction(ActionParser):
    """
    A continuous action space that support input actions in the range [-1, 1].
    The discrete actions are thresholded to be on or off.
    """
    ACTION_MASK = np.array([1, 1, 1, 1, 1, 0, 1, 0])
    ACTION_INDICES = ACTION_MASK.nonzero()[0]
    NUM_ACTIONS = ACTION_MASK.sum()

    def __init__(self, discrete_threshold: float = 0):
        super().__init__()
        self.discrete_threshold = discrete_threshold

    def get_action_space(self) -> Space:
        return Box(-1, 1, shape=(ContinuousThresholdAction.NUM_ACTIONS,))

    def parse_actions(self, actions: np.ndarray, state: GameState) -> np.ndarray:
        actions = actions.reshape((-1, ContinuousThresholdAction.NUM_ACTIONS))

        out = np.zeros((actions.shape[0], common_values.NUM_ACTIONS))
        out[..., ContinuousThresholdAction.ACTION_INDICES] = actions

        out[..., :5] = actions[..., :5].clip(-1, 1)

        # The final 3 actions handle are jump, boost and handbrake. They are
        # inherently discrete so we convert them to either 0 or 1.
        out[..., 5:] = out[..., 5:] > self.discrete_threshold

        return out
