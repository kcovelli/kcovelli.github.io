from typing import Tuple

import numpy as np
from rlgym.utils.state_setters import StateSetter, StateWrapper
from rlgym.utils.common_values import (
    SIDE_WALL_X, BACK_WALL_Y
)


class RandomGroundState(StateSetter):
    """
    Creates random states for cars and the ball on the ground.
    """
    def __init__(
            self,
            ball_center: Tuple[int, int],
            ball_radii: Tuple[int, int],
            car_center: Tuple[int, int],
            car_radii: Tuple[int, int]
        ):
        """
        Creates the random states with configurable randomness.

        Args:
            ball_center: The centerpoint of the ball to perturb.
            ball_radii: The radii of the ellipse around the center to place the
                ball in.
            car_center: The centerpoint of the car to perturb.
            car_radii: The radii of the ellipse around the center to place the
                car in.
        """
        super().__init__()

        self.ball_center = ball_center
        self.ball_radii = ball_radii
        self.car_center = car_center
        self.car_radii = car_radii

    def reset(self, state_wrapper: StateWrapper) -> None:
        """
        Sets the position of the ball and cars in the state wrapper.

        Args:
            state_wrapper: The state wrapper to set the positions in.
        """
        self._reset_ball(state_wrapper)
        self._reset_cars(state_wrapper)

    def _reset_ball(self, state_wrapper: StateWrapper) -> None:
        """
        Sets the position of the ball in the state wrapper.

        Args:
            state_wrapper: The state wrapper holding the ball position.
        """
        state_wrapper.ball.set_pos(
            np.random.random() * 2 * self.ball_radii[0] - self.ball_radii[0] + self.ball_center[0],
            np.random.random() * 2 * self.ball_radii[1] - self.ball_radii[1] + self.ball_center[1],
            100
        )

    def _reset_cars(self, state_wrapper: StateWrapper) -> None:
        """
        Sets the positions and rotations of the cars.

        Args:
            state_wrapper: The state wrapper to set the car positions and
                rotations in.
        """
        for car in state_wrapper.cars:
            # Make sure the cars are rotated towards the ball
            car.set_pos(
                np.random.random() * 2 * self.car_radii[0] - self.car_radii[0] + self.car_center[0],
                np.random.random() * 2 * self.car_radii[1] - self.car_radii[1] + self.car_center[1],
                17
            )

            car_ball_vec = state_wrapper.ball.position[:2] - car.position[:2]
            car_ball_vec_norm = car_ball_vec / np.linalg.norm(car_ball_vec)
            angle = np.arctan2(car_ball_vec_norm[1], car_ball_vec_norm[0])

            car.set_rot(yaw=angle)

            car.boost = 1

class RandomShootoutState(RandomGroundState):
    """
    A random state for a shootout scenario.
    """
    def __init__(
            self,
            ball_center: Tuple[int, int] = (0, BACK_WALL_Y / 3),
            ball_radii: Tuple[int, int] = (SIDE_WALL_X / 3, BACK_WALL_Y / 3),
            car_radii: Tuple[int, int] = (0, BACK_WALL_Y / 12)
        ):
        """
        Creates the random states for the ball, with the car spawning behind it.

        Args:
            ball_center: The centerpoint of the ball to perturb.
            ball_radii: The radii of the ellipse around the center to place the
                ball in.
            car_radii: The radius of the ellipse around the car position.
        """
        self.ball_center = ball_center
        self.ball_radii = ball_radii
        self.car_radii = car_radii

    def reset(self, state_wrapper: StateWrapper) -> None:
        """
        Sets the position of the ball and cars in the state wrapper.

        Args:
            state_wrapper: The state wrapper to set the positions in.
        """
        self._reset_ball(state_wrapper)
        self._reset_cars(state_wrapper)

    def _reset_ball(self, state_wrapper: StateWrapper) -> None:
        """
        Sets the position of the ball in the state wrapper.

        Args:
            state_wrapper: The state wrapper holding the ball position.
        """
        state_wrapper.ball.set_pos(
            np.random.random() * 2 * self.ball_radii[0] - self.ball_radii[0] + self.ball_center[0],
            np.random.random() * 2 * self.ball_radii[1] - self.ball_radii[1] + self.ball_center[1],
            100
        )

    def _reset_cars(self, state_wrapper: StateWrapper) -> None:
        """
        Sets the positions and rotations of the cars.

        Args:
            state_wrapper: The state wrapper to set the car positions and
                rotations in.
        """
        car_center = np.copy(state_wrapper.ball.position[:2])
        car_center[1] -= BACK_WALL_Y / 2

        for car in state_wrapper.cars:
            # Make sure the cars are rotated towards the ball
            car.set_pos(
                np.random.random() * 2 * self.car_radii[0] - self.car_radii[0] + car_center[0],
                np.random.random() * 2 * self.car_radii[1] - self.car_radii[1] + car_center[1],
                17
            )

            car_ball_vec = state_wrapper.ball.position[:2] - car.position[:2]
            car_ball_vec_norm = car_ball_vec / np.linalg.norm(car_ball_vec)
            angle = np.arctan2(car_ball_vec_norm[1], car_ball_vec_norm[0])

            car.set_rot(yaw=angle)

            car.boost = 1
