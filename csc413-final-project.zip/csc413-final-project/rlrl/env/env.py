from typing import Tuple

import rlgym
from rlgym.utils.action_parsers import ContinuousAction
from rlgym.utils.reward_functions import CombinedReward
from rlgym.utils.reward_functions.common_rewards import (
    LiuDistanceBallToGoalReward, LiuDistancePlayerToBallReward,
    VelocityBallToGoalReward, VelocityPlayerToBallReward, EventReward,
    AlignBallGoal, FaceBallReward, TouchBallReward, RewardIfBehindBall
)
from gym import Env

from rlrl.env.obs_builders import AdvancedObsNoPads
from rlrl.env.action_parsers import ContinuousThresholdAction
from rlrl.env.reward_functions import HeightReward
from rlrl.env.terminals import (
    ArtificialTerminalCondition, ArtificialTimeoutCondition,
    ArtificialGoalScoredCondition
)
from rlrl.env.state_setters import RandomShootoutState

def create_env(
        game_speed: int = 100
    ) -> Tuple[Env, Tuple[ArtificialTerminalCondition, ...]]:
    """
    Creates the Rocket League environment.

    Args:
        game_speed: The in-game time speed, 1 is normal, 100 is the maximum
            stable game speed.

    Returns:
        The created environment, and the tuple of terminal conditions it uses.
    """
    terminal_conditions = (
        ArtificialTimeoutCondition(225), ArtificialGoalScoredCondition()
    )

    env = rlgym.make(
        game_speed=game_speed,
        spawn_opponents=False,
        obs_builder=AdvancedObsNoPads(),
        action_parser=ContinuousThresholdAction(0.6),
        reward_fn=CombinedReward.from_zipped(
            (VelocityBallToGoalReward(), 1),
            (LiuDistancePlayerToBallReward(), 0.05),
            (VelocityPlayerToBallReward(), 0.5),
            (TouchBallReward(1.2), 3),
            (EventReward(goal=1), 50),
        ),
        terminal_conditions=terminal_conditions,
        state_setter=RandomShootoutState()
    )

    return env, terminal_conditions
